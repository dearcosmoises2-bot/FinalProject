Landfill e-Forms Workflow Deliverable

Files:
- Landfill_Workflow.tex: main LaTeX workflow document.
- workflow_diagram_body.tex: TikZ diagram body included by the main LaTeX file.
- Landfill_Workflow.pdf: compiled workflow document for review/submission.
- Landfill_Workflow_Diagram.png: standalone rendered workflow diagram.
- Landfill_Workflow_Diagram.pdf: standalone compiled workflow diagram.
- Landfill_Workflow_Diagram_Standalone.tex: standalone LaTeX wrapper for the diagram.

Suggested repo placement:
docs/workflow/Landfill_Workflow.tex
docs/workflow/workflow_diagram_body.tex
docs/workflow/Landfill_Workflow.pdf
